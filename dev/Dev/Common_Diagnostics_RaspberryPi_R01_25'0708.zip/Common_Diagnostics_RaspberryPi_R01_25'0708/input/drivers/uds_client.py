import can
import socket
import shutil 
import os
import isotp
import time
import logging
from datetime import datetime
from udsoncan.client import Client
from udsoncan.connections import PythonIsoTpConnection
from udsoncan.configs import default_client_config
from drivers.Parse_handler import load_testcases
from drivers.can_logger import CANLogger
from udsoncan import AsciiCodec
from drivers.report_generator import generate_report 
from udsoncan.services import WriteDataByIdentifier

class SafeAsciiCodec(AsciiCodec):
    def decode(self, data):
        try:
            return data.decode('ascii')
        except UnicodeDecodeError:
            return data.hex()


class UDSClient:
    def __init__(self, config):
        self.config =config      		
        can_cfg = config["uds"]["can"]
        isotp_cfg = config["uds"]["isotp"]
        timing_cfg = config["uds"]["timing"]
        self.uds_config = config["uds"]

        self.target_ecu = config["uds"].get("target_ecu", "Unknown ECU")
        self.context = {}

       
        self.udp_ip_ = config["uds"]["udp_server"]["ip"]
        self.udp_port_ = config["uds"]["udp_server"]["port"]
        self.expected_key_length_ = config["uds"]["udp_server"]["expected_key_length"]
        
        self.info_dids = self.uds_config.get("ecu_information_dids", {})
        self.decode_dids = self.uds_config.get("decoding_dids", {})
        self.write_data_dict = self.uds_config.get("write_data", {})
        self.step_delays=self.uds_config.get("delays",{})
        self.default_delay=self.step_delays.get("default",0.5)

       
        self.client_config = default_client_config.copy()
        self.client_config["p2_timeout"] = timing_cfg["p2_client"] / 1000.0
        self.client_config["p2_star_timeout"] = timing_cfg["p2_extended_client"] / 1000.0
        self.client_config["s3_client_timeout"] = timing_cfg["s3_client"] / 1000.0
        self.client_config["exception_on_negative_response"] = False
        self.client_config["exception_on_unexpected_response"] = False
        self.client_config["exception_on_invalid_response"] = False
        self.client_config["use_server_timing"] = False

        
        self.client_config["data_identifiers"] = {
            int(did_str, 16): SafeAsciiCodec(length)
            for did_str, length in self.decode_dids.items()
        }
        self.client_config["write_data"] = {
            int(did_str, 16): data_str
            for did_str, data_str in self.write_data_dict.items()
        }

        
        addr_modes_cfg = self.uds_config["addressing_modes"]
        self.physical_conn = self._create_connection(addr_modes_cfg.get("physical"), can_cfg, isotp_cfg, "physical")
        self.functional_conn = self._create_connection(addr_modes_cfg.get("functional"), can_cfg, isotp_cfg, "functional")

        self.active_conn = self.physical_conn
        self.active_mode = "physical"

        
        self.allowed_ids = list({
            int(addr_modes_cfg.get("physical", {}).get("tx_id", "0"), 16),
            int(addr_modes_cfg.get("physical", {}).get("rx_id", "0"), 16),
            int(addr_modes_cfg.get("functional", {}).get("tx_id", "0"), 16),
            int(addr_modes_cfg.get("functional", {}).get("rx_id", "0"), 16),
        })

        self.allowed_tx_ids = [
                  int(addr_modes_cfg.get("physical", {}).get("tx_id", "0"), 16),
                  int(addr_modes_cfg.get("functional", {}).get("tx_id", "0"), 16)
              ]

        self.allowed_rx_ids = [
             int(addr_modes_cfg.get("physical", {}).get("rx_id", "0"), 16),
             int(addr_modes_cfg.get("functional", {}).get("rx_id", "0"), 16)
         ]


        filters = self.get_can_filters()
        self.project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
        log_dir = os.path.join(self.project_root, 'output', 'can_logs')
        self.can_logger = CANLogger(channel=can_cfg["channel"], interface=can_cfg["interface"], log_dir=log_dir,filters=filters)


    def get_can_filters(self):
        filters_enabled = self.uds_config.get("logging", {}).get("filters", False)
        
        if not filters_enabled: 
            logging.info("CANLogger: Logging ALL CAN messages (no filters)")
            return None

        addr_modes_cfg = self.uds_config["addressing_modes"]
        tx_id_phys = int(addr_modes_cfg.get("physical", {}).get("tx_id", "0"), 16)
        rx_id_phys = int(addr_modes_cfg.get("physical", {}).get("rx_id", "0"), 16)

        tx_id_func = int(addr_modes_cfg.get("functional", {}).get("tx_id", "0"), 16)
        rx_id_func = int(addr_modes_cfg.get("functional", {}).get("rx_id", "0"), 16)

        filters = [
            {"can_id": tx_id_phys, "can_mask": 0x7FF, "extended": False},
            {"can_id": rx_id_phys, "can_mask": 0x7FF, "extended": False},
            {"can_id": tx_id_func, "can_mask": 0x7FF, "extended": False},
            {"can_id": rx_id_func, "can_mask": 0x7FF, "extended": False}
        ]

        logging.info("CANLogger: Logging only UDS traffic (tx/rx physical+functional)")
        return filters
    
    
    def _create_connection(self, addr_cfg, can_cfg, isotp_cfg, mode_name):
        if not addr_cfg:
            print(f"No config found for {mode_name} addressing, skipping.")
            return None

        tx_id = int(addr_cfg["tx_id"], 16)
        rx_id = int(addr_cfg["rx_id"], 16)
        is_extended = addr_cfg.get("is_extended", False)

        address = isotp.Address(
            addressing_mode=isotp.AddressingMode.Normal_29bits if is_extended else isotp.AddressingMode.Normal_11bits,
            txid=tx_id,
            rxid=rx_id
        )

        rx_mask = 0x1FFFFFFF if is_extended else 0x7FF
        bus = can.interface.Bus(
            channel=can_cfg["channel"],
            bustype=can_cfg["interface"],
            fd=can_cfg.get("can_fd", True),
            can_filters=[{
                "can_id": rx_id,
                "can_mask": rx_mask,
                "extended": is_extended
            }]
        )

        stack = isotp.CanStack(bus=bus, address=address, params=isotp_cfg)
        conn = PythonIsoTpConnection(stack)

        return {
            "conn": conn,
            "client_config": self.client_config,
            "mode_name": mode_name
        }
    def switch_mode(self, mode):
           mode = mode.lower()
           if mode == "physical" and self.physical_conn is not None:
               self.active_conn = self.physical_conn
               self.active_mode = "physical"
               #print("Switched to physical addressing")
           elif mode == "functional" and self.functional_conn is not None:
               self.active_conn = self.functional_conn
               self.active_mode = "functional"
               #print("Switched to functional addressing")
           else:
               raise ValueError(f"Unsupported or unconfigured addressing mode: {mode}")
    

    def check_disk_space(self, min_required_mb=50):
        total, used, free = shutil.disk_usage("/")
        free_mb = free // (1024 * 1024)  # Convert to MB
        return (free_mb >= min_required_mb, free_mb)

    def start_logging(self, log_name_suffix=""):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"CANLog_{log_name_suffix}_{timestamp}.asc"
        self.can_logger.start(filename=filename)

    def stop_logging(self):
        self.can_logger.stop()


                    
    def get_testcase_file_path(self):
            project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
            #project_root = os.path.dirname(os.path.abspath(__file__))
            file_path = os.path.join(project_root, 'input', 'supportfiles', 'testcase.txt')
	        
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"Testcase file not found: {file_path}")
	        
            return file_path

    

    def check_memory(self, oled):
        min_required = 50
        enough_space, free_mb = self.check_disk_space(min_required_mb=min_required)
        if not enough_space:
            warning_msg = f"Low Storage!\nOnly {free_mb}MB left.\nNeed {min_required}MB."
            oled.display_centered_text(warning_msg)
            logging.warning(warning_msg)
            time.sleep(4)
            return False

        #oled.display_centered_text(f"Storage OK\nFree: {free_mb} MB")
        logging.info(f"----------------------------------Storage OK Free: {free_mb} MB-----------------------------------------------")
        
        #logging.info(f"Storage check passed: {free_mb} MB available")
        time.sleep(2)
        return True

    def try_basic_communication(self):
        try:
            with Client(self.active_conn["conn"], request_timeout=2, config=self.client_config) as client:
                response = client.tester_present()
                return response.positive
        except Exception as e:
            logging.warning(f"Tester Present failed: {e}")
            return False

    
    def verify_response(self,raw_payload, expected_bytes, tc_id, step_desc):
 
            status = "Fail"
            failure_reason = "-"
    
            try:
                    expected_first_byte = expected_bytes[0]
                    actual_first_byte = raw_payload[0]
    
            # --- Negative response expected ---
                    if expected_first_byte == 0x7F:
                            if actual_first_byte == 0x7F:
                                    nrc_code = raw_payload[2] if len(raw_payload) >= 3 else None
                    
                                    if len(expected_bytes) == 1:
                                            # User gave only 0x7F → accept any NRC
                                            status = "Pass"
                                            logging.info(f"{tc_id} {step_desc} -> PASS (any NRC accepted because only 0x7F given)")
                                    elif len(expected_bytes) == 3:
                                            # User gave full expected negative response → check
                                            if nrc_code == expected_bytes[-1]:
                                                    status = "Pass"
                                                    logging.info(f"-----------------------------------------------{tc_id} {step_desc} -> PASS-----------------------------------------------")
                                            else:
                                                    failure_reason = f"Expected NRC {hex(expected_bytes[-1])}, got {hex(nrc_code) if nrc_code is not None else 'Unknown'}"
                                                    logging.warning(f"-----------------------------------------------{tc_id} {step_desc} -> FAIL - {failure_reason}-----------------------------------------------")
                                    else:
                                            failure_reason = f"Malformed expected bytes for negative response: {expected_bytes}"
                                            logging.error(f"-----------------------------------------------{tc_id} {step_desc} -> FAIL - {failure_reason}-----------------------------------------------")
                            else:
                                    failure_reason = f"Expected Negative Response (0x7F), but got Positive Response: {raw_payload}"
                                    logging.warning(f"-----------------------------------------------{tc_id} {step_desc} -> FAIL - {failure_reason}-----------------------------------------------")
                    
                    # --- Positive response expected ---
                    else:
                            if actual_first_byte != 0x7F:
                                    # Now — check first N bytes
                                    if raw_payload[:len(expected_bytes)] == expected_bytes:
                                            status = "Pass"
                                            logging.info(f"----------------------------------{tc_id} {step_desc} -> PASS-----------------------------------------------")
                                            
                                    else:
                                            failure_reason = f"Expected {expected_bytes}, got {raw_payload[:len(expected_bytes)]}"
                                            logging.warning(f"-----------------------------------------------{tc_id} {step_desc} -> FAIL - {failure_reason}-----------------------------------------------")
                            else:
                                    nrc_code = raw_payload[2] if len(raw_payload) >= 3 else None
                                    failure_reason = f"Expected Positive Response, but got NRC: {hex(nrc_code) if nrc_code is not None else 'Unknown'}"
                                    logging.warning(f"-----------------------------------------------{tc_id} {step_desc} -> FAIL - {failure_reason}-----------------------------------------------")
                    
            except Exception as e:
                    failure_reason = str(e)
                    logging.error(f"-----------------------------------------------{tc_id} {step_desc} -> EXCEPTION - {failure_reason}-----------------------------------------------")
    
            return status, failure_reason
            
    
    def get_ecu_information(self, oled=None, logging_enable=True):
                       
            testcase_file_path = self.get_testcase_file_path()
            if logging_enable:
                self.start_logging(log_name_suffix="ECU_Info")
            
            ecu_info = {}
            session_default = int(self.uds_config["default_session"], 16)
            session_extended = int(self.uds_config["extended_session"], 16)
            
            grouped_cases = load_testcases(testcase_file_path)
            time.sleep(0.5)
            
            def normalize_hex_string(val):
                return val.lower().replace("0x", "").strip()
            
            with Client(self.active_conn["conn"], request_timeout=2, config=self.client_config) as client:
                try:
                    client.change_session(session_default)
                    time.sleep(0.2)
                    client.change_session(session_extended)
                    time.sleep(0.2)
            
                except Exception as e:
                    if oled:
                        oled.display_centered_text(f"Session Error:\n{str(e)}")
                    logging.error(f"Session change failed: {e}")
                    return
            
                for tc_id, steps in grouped_cases.items():
                    if not tc_id.startswith("ECU_INFO"):
                        continue
            
                    logging.info(f"[ECU Info] Processing {tc_id}")
            
                    for step in steps:
                        logging.debug(f"[ECU Info] Step={step}")
            
                        try:
                            tc_id, step_desc, service, subfunc, expected, *rest = step
            
                            service_clean = normalize_hex_string(service)
                            subfunc_clean = normalize_hex_string(subfunc)
            
                            try:
                                service_int = int(service_clean, 16)
                                did = int(subfunc_clean, 16)
                            except ValueError as ve:
                                logging.error(f"[ECU Info] Invalid service or subfunc '{subfunc}' in {tc_id} step '{step_desc}': {ve}")
                                continue
            
                            # RAW request
                            if service_int == 0x22:  # ReadDataByIdentifier
                                did_hi = (did >> 8) & 0xFF
                                did_lo = did & 0xFF
                                raw_request = bytes([0x22, did_hi, did_lo])
                            else:
                                raw_request = bytes([service_int, did])
            
                            logging.info(f"[ECU Info] Sending raw request: {raw_request.hex()}")
            
                            client.conn.send(raw_request)
                            response = client.conn.wait_frame(timeout=2)
            
                            raw_payload = list(response)
                            logging.debug(f"[ECU Info] Received raw payload: {raw_payload}")
            
                            # Validate response
                            if service_int == 0x22:
                                if raw_payload[0] != 0x62:
                                    raise Exception(f"Unexpected response: {raw_payload}")
                                if raw_payload[1] != did_hi or raw_payload[2] != did_lo:
                                    raise Exception(f"DID mismatch: {raw_payload}")
            
                                raw_data = raw_payload[3:]
                            else:
                                raw_data = raw_payload[1:]
            
                            # Build HEX string
                            hex_str = ' '.join(f"{b:02X}" for b in raw_data)
            
                            # Try ASCII conversion if printable
                            try:
                                ascii_str = bytes(raw_data).decode("ascii").strip()
                                if all(32 <= ord(c) <= 126 for c in ascii_str):
                                    display_value = ascii_str
                                else:
                                    display_value = hex_str
                            except:
                                display_value = hex_str
            
                            # Store value
                            ecu_info[step_desc] = display_value
            
                            if oled:
                                oled.display_centered_text(f"{step_desc}\n{display_value}")
                                time.sleep(2)
            
                            logging.info(f"----------------------------------[ECU Info] {step_desc} ({subfunc}) = {display_value}-----------------------------------------------")
            
                        except Exception as e:
                            error_msg = str(e)[:40]
                            ecu_info[step_desc] = f"Error: {error_msg}"
            
                            if oled:
                                oled.display_centered_text(f"{step_desc}\nError: {error_msg}")
            
                            logging.error(f"----------------------------------[ECU Info] {step_desc} - Exception: {e}----------------------------------")
            
                        time.sleep(0.1)
                                   
            if logging_enable:
                self.stop_logging()
            return ecu_info

                   

    def run_testcase(self, oled):
        def wait_for_final_response(client, tc_id, step_desc, timeout_total=3.0):
            response = client.conn.wait_frame(timeout=2)
            time.sleep(0.05)
            start_time = time.time()
            while response and response[0] == 0x7F and response[2] == 0x78:
                  #time.sleep(1)
                  logging.info(f"{tc_id} {step_desc} -> 0x78 Response Pending, waiting for final response...")
                  response = client.conn.wait_frame(timeout=2)
                  time.sleep(1)
                  if time.time() - start_time > max_wait:
                     logging.warning(f"{tc_id} {step_desc} -> Timed out waiting after 0x78")
                     break
            return response
        
        if not self.check_memory(oled):
            return

        
        ecu_info_data = self.get_ecu_information(oled=None, logging_enable=False)
        testcase_file_path = self.get_testcase_file_path()
        self.start_logging(log_name_suffix="Testcase")
       
        grouped_cases = load_testcases(testcase_file_path)
        self.context = {}
        immediate_mode = self.config["uds"].get("immediate_mode", False)
        for tc_id, steps in grouped_cases.items():
        
            print("\n")
            logging.info(f"Running Test Case: {tc_id}")
        
            for step in steps:
                tc_id, step_desc, service, subfunc, expected, write_data, addressing = step
                
                try:
                    self.switch_mode(addressing)
        
                    with Client(self.active_conn["conn"], request_timeout=2, config=self.active_conn["client_config"]) as client:
        
                        logging.info(f"Switched to {addressing} mode for TC: {tc_id} Step: {step_desc}")
                        service_int = int(service, 16)
                        #subfunc_int = int(subfunc, 16)
                        expected_bytes = [int(b, 16) for b in expected.strip().split()]
                        data_to_write = [int(b, 16) for b in write_data.strip().split()] if write_data else []
        
                      
                        logging.info(f"{tc_id} - {step_desc}: SID={service}, Sub={subfunc}, Expected={expected_bytes}")
        
                        response = None
        
                        # Send UDS request
                              
                        if service_int == 0x10:
                            if subfunc != "":
              
                                subfunc_int = int(subfunc, 16)
                                raw_request = bytes([0x10, subfunc_int])
                                time.sleep(0.05)
                                client.conn.send(raw_request)
                                response = client.conn.wait_frame(timeout=4)
                                                         
                            elif subfunc == "":
                                 
                                        
                                        subfunc_clean = subfunc.strip()
                                        subfunc_bytes = bytes.fromhex(subfunc_clean) if subfunc_clean else b''
                                        expected_bytes = [int(b, 16) for b in expected.strip().split()]
                                        raw_request = bytearray([service_int]) + subfunc_bytes
                                        logging.info(f"{tc_id} - {step_desc}: Sending {raw_request.hex().upper()}")
                                        time.sleep(0.05)
                                        client.conn.send(raw_request)
                                        response = client.conn.wait_frame(timeout=2)
                                        
                        elif service_int == 0x11:
                              if subfunc != "":
                                subfunc_int = int(subfunc, 16)
                                raw_request = bytes([0x11, subfunc_int])
                                time.sleep(0.05)
                                if subfunc_int == 0x01:
                                   client.conn.send(raw_request)
                                   response = client.conn.wait_frame(timeout=2)
                                   time.sleep(1)
                                else:
                                   client.conn.send(raw_request)
                                   response = client.conn.wait_frame(timeout=2)
                                                        
                              elif subfunc == "":
                                 
                                       # service_int = int(service, 16)
                                        subfunc_clean = subfunc.strip()
                                        subfunc_bytes = bytes.fromhex(subfunc_clean) if subfunc_clean else b''
                                        expected_bytes = [int(b, 16) for b in expected.strip().split()]
                                        raw_request = bytearray([service_int]) + subfunc_bytes
                                        time.sleep(0.05)
                                        client.conn.send(raw_request)
                                        response = client.conn.wait_frame(timeout=2)
                                        
                            
                        elif service_int == 0x22:
                              if subfunc != "":   
                                subfunc_int = int(subfunc, 16)    
                                did_hi = (subfunc_int >> 8) & 0xFF
                                did_lo = subfunc_int & 0xFF
                                raw_request = bytes([0x22, did_hi, did_lo])
                                #time.sleep(0.05)
                                client.conn.send(raw_request)
                                response = wait_for_final_response(client, tc_id, step_desc)                       
                              elif subfunc == "":                               
                                        subfunc_clean = subfunc.strip()
                                        subfunc_bytes = bytes.fromhex(subfunc_clean) if subfunc_clean else b''
                                        expected_bytes = [int(b, 16) for b in expected.strip().split()]
                                        raw_request = bytearray([service_int]) + subfunc_bytes
                                        #time.sleep(0.05)
                                        client.conn.send(raw_request)
                                        response = wait_for_final_response(client, tc_id, step_desc)
                                       
        
                        elif service_int == 0x2E:
                            subfunc_int = int(subfunc, 16)
                            if not data_to_write:
                                raise ValueError(f"No write data provided in testcase for DID {hex(subfunc_int)}")
        
                            did_hi = (subfunc_int >> 8) & 0xFF
                            did_lo = subfunc_int & 0xFF
                            raw_request = bytes([0x2E, did_hi, did_lo] + data_to_write)
        
                            client.conn.send(raw_request)
                            response = client.conn.wait_frame(timeout=2)
        
                            
        
                        elif service_int == 0x19:
                              if subfunc != "":
                                
                                subfunc_int = int(subfunc, 16)
                                status_mask = 0xFF
                                raw_request = bytes([0x19, subfunc_int, status_mask])
                                client.conn.send(raw_request)
                                response_data = client.conn.wait_frame(timeout=2)
                                                        
                              elif subfunc == "":
                                 
                                        subfunc_clean = subfunc.strip()
                                        subfunc_bytes = bytes.fromhex(subfunc_clean) if subfunc_clean else b''
                                        expected_bytes = [int(b, 16) for b in expected.strip().split()]
                                        raw_request = bytearray([service_int]) + subfunc_bytes
                                        logging.info(f"{tc_id} - {step_desc}: Sending {raw_request.hex().upper()}")
                                        
                                        client.conn.send(raw_request)
                                        response_data = client.conn.wait_frame(timeout=2)
                                        
                        elif service_int == 0x14:  # ClearDiagnosticInformation
                              if subfunc != "":  
                                subfunc_int = int(subfunc, 16)
                                dtc_group_bytes = [(subfunc_int >> shift) & 0xFF for shift in (16, 8, 0)]
                                raw_request = bytes([0x14] + dtc_group_bytes)
                                client.conn.send(raw_request)
                                response_data = client.conn.wait_frame(timeout=2)
                              elif subfunc == "":
                                
                                        subfunc_clean = subfunc.strip()
                                        subfunc_bytes = bytes.fromhex(subfunc_clean) if subfunc_clean else b''
                                        expected_bytes = [int(b, 16) for b in expected.strip().split()]
                                        raw_request = bytearray([service_int]) + subfunc_bytes
                                        logging.info(f"{tc_id} - {step_desc}: Sending {raw_request.hex().upper()}")
                                        
                                        client.conn.send(raw_request)
                                        response_data = client.conn.wait_frame(timeout=2)
                                        logging.info(f"{tc_id} - Received: {response_data.hex().upper()}")

                        elif service_int == 0x3E:  # TesterPresent
                              if subfunc != "":
                                
                                subfunc_int = int(subfunc, 16)
                                raw_request = bytes([0x3E, subfunc_int])
                                client.conn.send(raw_request)
                                response_data = client.conn.wait_frame(timeout=2)
                                                    
                              elif subfunc == "":
                                 
                                        subfunc_clean = subfunc.strip()
                                        subfunc_bytes = bytes.fromhex(subfunc_clean) if subfunc_clean else b''
                                        expected_bytes = [int(b, 16) for b in expected.strip().split()]
                                        raw_request = bytearray([service_int]) + subfunc_bytes
                                        
                                        client.conn.send(raw_request)
                                        response_data = client.conn.wait_frame(timeout=2)
                                       
                        elif service_int == 0x85:
                              if subfunc != "":
                                
                                subfunc_int = int(subfunc, 16)
                                raw_request = bytes([0x85, subfunc_int])
                                client.conn.send(raw_request)
                                response_data = client.conn.wait_frame(timeout=2)
                                                        
                              elif subfunc == "":
                                
                                        subfunc_clean = subfunc.strip()
                                        subfunc_bytes = bytes.fromhex(subfunc_clean) if subfunc_clean else b''
                                        expected_bytes = [int(b, 16) for b in expected.strip().split()]
                                        raw_request = bytearray([service_int]) + subfunc_bytes
                                        
                                        client.conn.send(raw_request)
                                        response_data = client.conn.wait_frame(timeout=2)
                                        
        
                        elif service_int == 0x27:
        
                            subfunc_int = int(subfunc, 16)
                            if subfunc_int % 2 == 1:  # requestSeed
                                raw_request = bytes([0x27, subfunc_int])
                                client.conn.send(raw_request)
                                response = wait_for_final_response(client, tc_id, step_desc)
        
                                raw_payload = list(response)
                                logging.debug(f"{tc_id} {step_desc} -> Received payload: {raw_payload}")
        
                                if raw_payload[0] != 0x67 or raw_payload[1] != subfunc_int:
                                    failure_reason = f"NRC (seed): {raw_payload}"
                                    logging.warning(f"{tc_id} {step_desc} -> FAIL - {failure_reason}")
                                    raise Exception(failure_reason)
        
                                seed = bytes(raw_payload[2:])
                                self.context[f"seed_{subfunc_int}"] = seed
                                logging.info(f"Received Seed (subfunc {hex(subfunc_int)}): {seed.hex()}")
                                time.sleep(0.5)
        
                                # Send seed to PC and get key
                                udp_ip = self.udp_ip_
                                udp_port = self.udp_port_
                                max_retries = 3
                                retry_delay = 1.0
                                expected_key_length = self.expected_key_length_
        
                                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                                sock.settimeout(5)
        
                                try:
                                    for attempt in range(1, max_retries + 1):
                                        try:
                                            logging.info(f"Attempt {attempt}: Sending seed to PC...")
                                            sock.sendto(seed.hex().encode(), (udp_ip, udp_port))
                                            key, _ = sock.recvfrom(1024)
                                            key = key.strip()
        
                                            if not key:
                                                raise Exception("Received empty key from PC")
                                            if len(key) != expected_key_length:
                                                raise Exception(f"Invalid key length: expected {expected_key_length}, got {len(key)}")
        
                                            self.context[f"key_{subfunc_int + 1}"] = key
                                            logging.info(f"Received Key (for subfunc {hex(subfunc_int + 1)}): {key}")
                                            break
        
                                        except socket.timeout:
                                            logging.warning(f"Attempt {attempt} - Timeout waiting for key.")
                                            if attempt < max_retries:
                                                time.sleep(retry_delay)
                                            else:
                                                raise Exception(f"Timeout after {max_retries} retries waiting for key from PC")
        
                                        except Exception as e:
                                            logging.exception(f"Attempt {attempt} - Error occurred:")
                                            if attempt == max_retries:
                                                raise
                                finally:
                                    sock.close()
        
                            elif subfunc_int % 2 == 0:  # sendKey
        
                                key = self.context.get(f"key_{subfunc_int}")
                                if not key:
                                    raise Exception(f"No key available for subfunction {hex(subfunc_int)}. Ensure seed request precedes key send.")
        
                                raw_request = bytes([0x27, subfunc_int]) + key
                                client.conn.send(raw_request)
                                response = wait_for_final_response(client, tc_id, step_desc)
        
                                raw_payload = list(response)
                                logging.debug(f"{tc_id} {step_desc} -> Received payload: {raw_payload}")
        
                                if raw_payload[0] != 0x67 or raw_payload[1] != subfunc_int:
                                    failure_reason = f"NRC (key): {raw_payload}"
                                    logging.warning(f"{tc_id} {step_desc} -> FAIL - {failure_reason}")
                                    raise Exception(failure_reason)
        
                            else:
                                raise ValueError(f"Unsupported subfunction for service 0x27: {hex(subfunc_int)}")
        
                        elif service_int == 0x28:
                            if subfunc != "":
                             try:
                                 subfunc_clean = subfunc.strip()
                                 control_type = int(subfunc_clean, 16)
                                 communication_type = control_type 
                                 # Determine communication type dynamically
                                 
                                      
                                 
                             
                                 
                                 raw_request = bytes([0x28, control_type, communication_type])
                                 logging.info(f"{tc_id} - {step_desc}: Sending raw request {raw_request.hex().upper()}")
                                 client.conn.send(raw_request)
                                 response = wait_for_final_response(client, tc_id, step_desc)
                             
                                                              
                             except ValueError:
                                 logging.error(f"{tc_id} - Invalid subfunction format: '{subfunc}'")
                             except Exception as e:
                                 logging.error(f"{tc_id} - Error sending CommunicationControl raw request: {e}")
                            elif subfunc == "":
                                 
                                        subfunc_clean = subfunc.strip()
                                        subfunc_bytes = bytes.fromhex(subfunc_clean) if subfunc_clean else b''
                                        expected_bytes = [int(b, 16) for b in expected.strip().split()]
                                        raw_request = bytearray([service_int]) + subfunc_bytes
                                        
                                        client.conn.send(raw_request)
                                        response_data = client.conn.wait_frame(timeout=2)
                                
                              
                        # === Response Verification ===
                        if response is not None:
        
                            try:
                                raw_payload = list(response)
                                logging.debug(f"{tc_id} {step_desc} -> Received payload: {raw_payload}")
        
                                status, failure_reason = self.verify_response(raw_payload, expected_bytes, tc_id, step_desc)
        
        
                            except Exception as e:
                                status = "Fail"
                                failure_reason = f"Could not extract payload: {str(e)}"
                                logging.error(f"----------------------------------{tc_id} {step_desc} -> FAIL - {failure_reason}----------------------------------")
                        else:
                            status = "Fail"
                            failure_reason = "No response received (timeout)"
                            logging.error(f"----------------------------------{tc_id} {step_desc} -> FAIL - {failure_reason}----------------------------------")
        
                except Exception as e:
                    status = "Fail"
                    failure_reason = str(e)
                    logging.error(f"----------------------------------{tc_id} {step_desc} -> EXCEPTION - {failure_reason}----------------------------------")
                try:			 
                    #oled.display_centered_text(f"{tc_id}\n{step_desc[:20]}\n{status}")
                    if not immediate_mode:
                            delay_key=service.upper()
                            delay=float(self.step_delays.get(delay_key,self.default_delay))
                            oled.display_centered_text(f"{tc_id}\n{step_desc[:20]}\n{status}")
                            time.sleep(delay)
                except Exception as e:
                       logging.error(f"----------------------------------{tc_id} {step_desc} -> FAIL - {failure_reason}----------------------------------")

        self.stop_logging()
        time.sleep(1.5)

        full_log_path = self.can_logger.get_log_path() or "N/A"
        can_log_file = os.path.basename(full_log_path)

        # Confirm log file presence
        if not os.path.isfile(full_log_path):
            logging.error(f"File not found after logging stopped: {full_log_path}")
            oled.display_centered_text("Log Error!\nFile Missing.")
            return
        else:
            
            logging.info("----------------------------------Log Generated!----------------------------------")
            time.sleep(2)

        report_dir = os.path.join(self.project_root, 'output', 'html_reports')
        os.makedirs(report_dir, exist_ok=True)
        report_filename = f"UDS_Report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
        report_path = os.path.join(report_dir, report_filename)

        # Wait for log file to appear (max 3 seconds)
        for _ in range(6):
            if os.path.exists(full_log_path):
                print(f"Log file found: {full_log_path}")
                break
            else:
                print(f" Waiting for log file to appear: {full_log_path}")
                time.sleep(0.5)
        else:
            print(f"File not found: {can_log_file}")

        generate_report(
            asc_file_path=full_log_path,
            txt_file_path=testcase_file_path,
            output_html_file=report_path,
            allowed_tx_ids=self.allowed_tx_ids,
            allowed_rx_ids =self.allowed_rx_ids,
            ecu_info_data = ecu_info_data,
            target_ecu=self.target_ecu
        )

        oled.display_centered_text("Report Generated")
        logging.info("----------------------------------Report Generated----------------------------------")
                    
        time.sleep(2)
       


