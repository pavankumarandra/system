from datetime import datetime
import os

def load_description_map(txt_file_path):
    
    desc_map = {}
    with open(txt_file_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or not line.lower().startswith("tc_"):
                continue
            parts = line.split(",")
            if len(parts) < 5:
                continue
            description = parts[1].strip()
            sid = parts[2].strip().replace("0x", "").upper()
            sub = parts[3].strip().replace("0x", "").upper()
            desc_map[(sid, sub)] = description
    return desc_map
txt_file_path="/home/mobase/dfs/demo/udsoncan/input/supportFiles/testcase.txt"

description_map=load_description_map(txt_file_path)

def get_description( data_bytes):
    if not data_bytes or len(data_bytes) < 2:
        return ""
    sid_index = 2 if data_bytes[0].startswith("1") else 1
    if len(data_bytes) <= sid_index:
        return ""
    sid = data_bytes[sid_index]
    for length in (3, 2, 1):
        if sid_index + length < len(data_bytes):
            sub = ''.join(data_bytes[sid_index + 1: sid_index + 1 + length])
            key = (sid, sub)
            if key in description_map:
                return description_map[key]
    return ""

def is_header_or_comment(line):
    stripped=line.strip().lower()
    return (
        stripped == "" or
        stripped.startswith("base hex") or
        stripped.startswith("begin triggerblock") or
        stripped.startswith("date") or
        stripped.startswith("internal") or
        "start of measurement" in stripped
    )

def is_continuation_frame(data_bytes):
    return data_bytes and (data_bytes[0].upper().startswith("2") or data_bytes[0].upper() == "30")

def get_failure_reason(nrc):
     nrc_map = {
        "10" : "generalReject",
        "11" : "serviceNotSupported",
        "12" : "subFunctionNotSupported",
        "13" : "incorrectMessageLengthOrInvalidFormat",
        "14" : "responseTooLong",
        "21" : "busyRepeatReques",
        "22" : "conditionsNotCorrect",
        "23" : "ISOSAEReserved",
        "24" : "requestSequenceError",
        "31" : "requestOutOfRange",
        "32" : "ISOSAEReserved",
        "33" : "securityAccessDenied",
        "34" : "ISOSAEReserved",
        "35" : "invalidKey",
        "36" : "exceedNumberOfAttempts",
        "37" : "requiredTimeDelayNotExpired",
        "70" : "uploadDownloadNotAccepted",
        "71" : "transferDataSuspended",
        "72" : "generalProgrammingFailure",
        "73" : "wrongBlockSequenceCounter",
        "78" : "requestCorrectlyReceived-ResponsePending",
        "7E" : "subFunctionNotSupportedInActiveSession",
        "7F" : "serviceNotSupportedInActiveSession",
        "80" : "ISOSAEReserved",
        "81" : "rpmTooHigh",
        "82" : "rpmTooLow",
        "83" : "engineIsRunning",
        "84" : "engineIsNotRunning",
        "85" : "engineRunTimeTooLow",
        "86" : "temperatureTooHigh",
        "87" : "temperatureTooLow",
        "88" : "vehicleSpeedTooHigh",
        "89" : "vehicleSpeedTooLow",
        "8A" : "throttle/PedalTooHigh",
        "8B" : "throttle/PedalTooLow",
        "8C" : "transmissionRangeNotInNeutral",
        "8D" : "transmissionRangeNotInGear",
        "8E" : "ISOSAEReserved",
        "8F" : "brakeSwitch(es)NotClosed (Brake Pedal not pressed or not applied)",
        "90" : "shifterLeverNotInPark",
        "91" : "torqueConverterClutchLocked",
        "92" : "voltageTooHigh",
        "93" : "voltageTooLow",
        "FF" : "ISOSAEReserved",
    }
     return f"NRC {nrc} : {nrc_map[nrc]}"

def get_status(data_bytes):
    if len(data_bytes) >= 4 and data_bytes[1] == "7F" and data_bytes[3] == "78":
        return "Pending", ""
    if len(data_bytes) >= 4 and data_bytes[1] == "7F":
        return "Fail", get_failure_reason(data_bytes[3])
    pass_ids = {"50", "51", "54", "59", "C5", "68", "67", "62", "7E", "6E", "71", "74", "76", "77", "63", "64", "6F"}
    if len(data_bytes) > 1 and not data_bytes[0].startswith("1") and data_bytes[1] in pass_ids:
        return "Pass", ""
    if len(data_bytes) > 2 and data_bytes[0].startswith("1") and data_bytes[2] in pass_ids:
        return "Pass", ""
    return None, ""



def parse_line( line, allowed_ids):
    allowed_ids={'716','71E'}
    parts = line.strip().split()
    if len(parts) < 8:
        return None
    try:
        timestamp = float(parts[0])
        msg_id = parts[2].upper()
        direction = parts[3]
        if parts[4].lower() != "d":
            return None
        dlc = int(parts[5])
        data_bytes = [b.upper() for b in parts[6:6 + dlc]]
        while len(data_bytes) < 8:
            data_bytes.append("00")
        if msg_id not in allowed_ids or is_continuation_frame(data_bytes):
            return None
        
        msg = {
            "timestamp": timestamp,
            "id": msg_id,
            "direction": direction,
            "data": data_bytes,
            "description": get_description(data_bytes)
        }
        if direction == "Rx":
            status, reason = get_status(data_bytes)
            if status == "Pending":
                return None
            msg["status"] = status
            msg["reason"] = reason
        else:
            msg["status"] = "Tx"
            msg["reason"] = "-"
        return msg
    except Exception as e:
        print(f"Error parsing line: {line.strip()} - {e}")
        return None

def group_test_cases( messages):
    test_cases = []
    current = {"steps": []}
    for msg in messages:
        step = {
            "timestamp": msg["timestamp"],
            "type": "Request Sent" if msg["direction"] == "Tx" else "Response Received",
            "description": msg["description"],
            "status": msg["status"] if msg["direction"] == "Rx" else "",
            "reason": msg.get("reason", "-")
        }
        current["steps"].append(step)
        if msg["direction"] == "Rx":
            current["status"] = msg["status"]
            test_cases.append(current)
            current = {"steps": []}
    return test_cases

def generate_html_report( input_asc_file, test_cases, duration):
    total = len(test_cases)
    passed = sum(1 for tc in test_cases if tc["status"] == "Pass")
    failed = total - passed
    generated_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    html = f"""<html><head><title>UDS Diagnostic Report</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {{ font-family: Arial; margin: 20px; }}
        .pass {{ color: green; font-weight: bold; }}
        .fail {{ color: red; font-weight: bold; }}
        summary {{ font-weight: bold; cursor: pointer; }}
        table {{ border-collapse: collapse; width: 100%; margin-top: 10px; }}
        th, td {{ border: 1px solid #ccc; padding: 8px; }}
        th {{ background: #f0f0f0; }}
        #chart-container {{ width: 300px; margin: 20px auto; }}
    </style></head><body>
    <h1>UDS Diagnostic Report</h1>
    <div><strong>Generated:</strong> {generated_time}</div>
    <div><strong>CAN Log File:</strong> {input_asc_file}</div>
    <div><strong>Total Test Cases:</strong> {total}</div>
    <div class="pass">Passed: {passed}</div>
    <div class="fail">Failed: {failed}</div>
    <div><strong>Test Duration:</strong> {duration:.3f} seconds</div>

    <div id="chart-container"><canvas id="passFailChart"></canvas></div>

    <script>
        const ctx = document.getElementById('passFailChart').getContext('2d');
        new Chart(ctx, {{
            type: 'pie',
            data: {{
                labels: ['Passed', 'Failed'],
                datasets: [{{
                    data: [{passed}, {failed}],
                    backgroundColor: ['#4CAF50', '#F44336']
                }}]
            }},
            options: {{
                responsive: true,
                plugins: {{
                    legend: {{
                        position: 'bottom'
                    }},
                    title: {{
                        display: true,
                        text: 'Test Case Results'
                    }}
                }}
            }}
        }});
    </script><hr><br>"""

    for idx, case in enumerate(test_cases, 1):
        status_class = "pass" if case["status"] == "Pass" else "fail"
        html += f"<details><summary>TC_{idx:03d} - <span class='{status_class}'>{case['status']}</span></summary>\n"
        html += "<table><tr><th>Step</th><th>Description</th><th>Timestamp</th><th>Type</th><th>Status</th><th>Failure Reason</th></tr>\n"
        for step_idx, step in enumerate(case["steps"], 1):
            html += f"<tr><td>{step_idx}</td><td>{step['description']}</td><td>{step['timestamp']:.6f}</td><td>{step['type']}</td><td>{step.get('status', '')}</td><td>{step.get('reason', '-')}</td></tr>\n"
        html += "</table></details>\n"

    html += "</body></html>"
    return html

def generate_report(input_asc_file, output_html_file="UDS_Report.html", allowed_ids=None):
    allowed_ids={'716','71E'}
    if not os.path.isfile(input_asc_file):
        print(f"\u274C File not found: {input_asc_file}")
        return

    messages = []
    with open(input_asc_file, "r") as f:
        for line in f:
            if is_header_or_comment(line):
                continue
            msg = parse_line(line, allowed_ids)
            if msg:
                messages.append(msg)

    if not messages:
        print("\u26A0\uFE0F No valid messages found.")
        return

    messages.sort(key=lambda x: x["timestamp"])
    test_cases = group_test_cases(messages)
    duration = messages[-1]["timestamp"] - messages[0]["timestamp"]
    report = generate_html_report(os.path.basename(input_asc_file), test_cases, duration)

    with open(output_html_file, "w", encoding="utf-8") as f:
        f.write(report)

    print(f"\u2705 Report generated: {output_html_file}")
