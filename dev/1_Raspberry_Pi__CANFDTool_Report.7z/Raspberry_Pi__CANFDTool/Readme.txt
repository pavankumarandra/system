Place testcase file(testcase.txt) in following path : \input\supportfiles
(Note: follow testcase file naming convension as testcase.txt)
Find Source code(main.py) in following path : \input\application\main.py
Find configuration file(config.json) in following path : \input\application\config.json
