/******************Revision History*******************/
File Name: Readme.txt (\..\CDT_ProjectFiles\Readme.txt)
R01 - 25'07/09 - Initial Version - by Sahithi
R02 - 26'01/30 - Updated the document format and added details for updating the
configuration file using Update_JSON.exe – by Prudhvi Raj

/****************************************************/
Project Setup Instructions
1.Place the testcase file (testcase.txt) in the path \CDT_ProjectFiles\input\supportfiles.
(Note: Ensure that the testcase file naming convention is strictly followed.)
2.The source file main.py is located at \CDT_ProjectFiles\input\application\main.py.
3.The configuration file config.json is available at \CDT_ProjectFiles\input\application\config.json.
(Note: The configuration file can be modified using Update_JSON.exe, which is located in the path CDT_ProjectFiles\json)
4.In uds_client.py, update the udp_ip variable with the IP address of the PC on which the UDP server is running.